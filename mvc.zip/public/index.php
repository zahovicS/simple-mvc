<?php
require_once dirname(__DIR__, 1) . "/App/kernel.php";
$inic = new Router;