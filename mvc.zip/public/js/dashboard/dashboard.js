$(function () {
  $('#example').DataTable({
    dom: DEFAULT_DOM_DATATABLE,
    language: DEFAULT_ES_DATATABLE,
  })
})
