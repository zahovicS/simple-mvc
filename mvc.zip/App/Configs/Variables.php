<?php
define('RUTE_APP', dirname(dirname(__FILE__))); //nombre del proyecto - carpeta
define('BASE_URL', 'http://localhost/mvc'); //base url
define('URI_PROJECT', '/mvc'); //base url
define('NAME_PROJECT', 'SISTEMA DE VENTAS'); //base url
define('DB_SERVER', 'localhost'); //servidor
define('DB_NAME', 'dbsistema'); //nombre de la base de datos
define('DB_PORT', 3306); //puerto de la base de datos
define('DB_CHARSET', 'utf8'); //charset de la base de datos
define('DB_USER', 'root'); //usuarios de la base de datos
define('DB_PASS', 'root'); //contraseña de la base de datos