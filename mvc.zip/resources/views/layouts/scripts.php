<script>
const base_url = '<?= BASE_URL ?>';
</script>
<script src="<?= BASE_URL ?>/bower_components/axios/dist/axios.min.js"></script>
<script src="<?= BASE_URL ?>/bower_components/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="<?= BASE_URL ?>/bower_components/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?= BASE_URL ?>/bower_components/jquery-validation/dist/localization/messages_es_PE.min.js"></script>
<script src="<?= BASE_URL ?>/js/scripts.js"></script>