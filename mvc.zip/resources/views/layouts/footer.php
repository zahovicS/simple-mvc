<footer class="footer">
    <div class="container-fluid">
        <div class="level">
            <div class="level-left">
                <div class="level-item">
                    © 2022, MVC
                </div>
            </div>
            <div class="level-right">
                <div class="level-item">
                    <div class="logo">
                        <a href="#!"><img src="<?= BASE_URL ?>/images/favicons/favicon-16x16.png" alt="MVC"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>
<script src="<?= BASE_URL ?>/js/main.js"></script>
</body>

</html>